import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-formreactive',
  templateUrl: './formreactive.component.html',
  styleUrls: ['./formreactive.component.css']
})

export class FormreactiveComponent implements OnInit {
  srcUrl: any = '';
  form = new FormGroup({
    animalName: new FormControl('',
    [
      Validators.required,
      Validators.minLength(2),
      Validators.maxLength(20),
    ])
   });
    constructor() { }
  
    get animalName(){
      return this.form.get('animalName')
    }
    ngOnInit() {
    }
  
    onSubmit(){
      setTimeout(() => {
    // Random dimension avoids image caching
   this.srcUrl = "https://picsum.photos/id/237/200/300";
  });
    }

    reset() {
      this.form.reset();
      this.srcUrl = '';
    }

}

  