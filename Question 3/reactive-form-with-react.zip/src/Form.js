import React, { Component } from 'react';
import { FormErrors } from './FormErrors';
import './Form.css';

const unsplashImg = document.getElementById("unsplashImage");

class Form extends Component {
      constructor(props) {
            super(props);
            this.state = {
                  animalName: '',
                  formErrors: { animalName: ''},
                  animalNameValid: false,
                  formValid: false
            }
      }

      handleSubmit(event) {
            event.preventDefault();
                  unsplashImg.src = "https://picsum.photos/id/237/200/300";
      }

      handleUserInput = (e) => {
            const name = e.target.name;
            const value = e.target.value;
            this.setState({ [name]: value },
                  () => { this.validateField(name, value) });
      }

      validateField(fieldName, value) {
            let fieldValidationErrors = this.state.formErrors;
            let animalNameValid = this.state.animalNameValid;

            switch (fieldName) {
                  case 'animalName':
                        animalNameValid = (value.length >= 2) && (value.length <=20);
                        fieldValidationErrors.animalName = animalNameValid ? '' : ' is out of range';
                        break;
                  default:
                        break;
            }
            this.setState({
                  formErrors: fieldValidationErrors,
                  animalNameValid: animalNameValid
            }, this.validateForm);
      }

      validateForm() {
            this.setState({ formValid: this.state.animalNameValid });
      }

      errorClass(error) {
            return (error.length === 0 ? '' : 'has-error');
      }

      render() {
            return (
                  <form className="animalForm" onSubmit={this.handleSubmit}>
                        <h2>Let's get your hero name...</h2>
                        <div className="panel panel-default">
                              <FormErrors formErrors={this.state.formErrors} />
                        </div>
                        <div className={`form-group ${this.errorClass(this.state.formErrors.animalName)}`}>
                              <label htmlFor="animalName">Animal Name</label>
                              <input type="text" required className="form-control" name="animalName"
                                    placeholder="lion king"
                                    value={this.state.animalName}
                                    onChange={this.handleUserInput} />
                        </div>
                        <button type="submit" className="mb5 btn btn-primary" disabled={!this.state.formValid}>Get Hero Picture</button> <br/>
                        <img src="" id="unsplashImage"></img>
                  </form>

                 
            )
      }
}

export default Form;
